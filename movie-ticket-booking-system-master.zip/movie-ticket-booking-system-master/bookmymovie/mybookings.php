<!doctype html>
<html lang="en">
	<head>
		<?php include 'components/header.php';?>

		<title>BookMyMovie | My Bookings</title>
	</head>
	<body>
		<?php include 'components/navbar.php';?>

		<div class="container">


		</div>

	  <div>
	    <p class="spacer"></p>
	  </div>

		<?php include 'components/footer.php';?>
	</body>
</html>
